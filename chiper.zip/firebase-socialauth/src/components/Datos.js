
import { PageHeader, Button } from "antd";
import app from '../firebaseConfig'
import {Link} from "react-router-dom"
import React, { Component,useEffect, useContext ,useState } from 'react';
import ReactDOM from 'react-dom';
import * as firebase from "firebase/app";
import { Layout } from "antd";
import { Auth } from "../context/AuthContext";


const day  = (new Date()).getDate();
const mes= (new Date()).getMonth();
const año = (new Date()).getFullYear();
const hora= (new Date()).getHours();
const min=(new Date()).getMinutes();


class Datos extends Component {

  constructor() {
    super();
    this.ref = firebase.firestore().collection('boards');
    this.state = {
      trasmision: '',
      title: '',
      author: '',
      fecha:'',


    };
  }
  onChange = (e) => {
    const state = this.state
    state[e.target.name] = e.target.value;
    this.setState(state);
  }

  onSubmit = (e) => {
    e.preventDefault();

    const { title,fecha,trasmision,author, } = this.state;

    this.ref.add({
      trasmision,
      title,
      author,
      fecha,
    }).then((docRef) => {
      this.setState({
        title: '',
        trasmision: '',
        author: '',
        fecha:'',
 
      });
      this.props.history.push("/")
    })
    .catch((error) => {
      console.error("Error adding document: ", error);
    });
  }

  render() {
    const { title,trasmision,author,ID,fecha } = this.state;
    return (

    	<div
       style={{
                            justifyContent:"center",
                            padding:3,
                            textAlign: "center",
                        }}

      >
          <div>
            <h1>
              Agregar Registro
            </h1>
          </div>
          <div class="panel-body">
            <h3><Link to="/" class="btn btn-primary"
                style={{
                  color:"rgba(250,2,54)"
                }}>Lista de registro</Link></h3>
            <form onSubmit={this.onSubmit}>
              <div>
                <label for="title">Nombre del streaming:</label>
                </div>
                <div>
                <input type="text" class="form-control" name="title" value={title} onChange={this.onChange} placeholder="Titulo" />
              </div>

               <div>
                <label class="form-control" name="link" onChange={this.onChange} placeholder="Description" cols="80" rows="3">ID trasmision</label>

              </div>
              <div>
                <input type="text" class="form-control" name="trasmision"  onChange={this.onChange} placeholder="ID"  />
              </div>
              <div >
                <label for="">Nombre embajador:</label>
                </div>
               <div>
                <input type="text" class="form-control" name="author" value={author} onChange={this.onChange} placeholder="Embajador" />
              </div>
              <div>
                <label>Fecha:</label>
              </div>
              <div>
              <input type="text" class="form-control" name="fecha" value={day} onChange={this.onChange} placeholder="Fecha" />
              
              </div>

              <div>
                <h3>

                </h3>

              </div>


              <Button                                      
                
                                    color=" color:rgba(250,2,54)"
                                    type="primary"
                                    htmlType="submit"
                                    className="login-form-button"
                                  
                                    style={{
                                        padding:2,
                                         marginRight: 10 }}


              >
              Submit

              </Button>
            </form>
          </div>
        </div>

      
    );
  }
}

export default Datos;
