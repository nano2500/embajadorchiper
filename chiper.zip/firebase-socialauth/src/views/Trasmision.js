import React, { useEffect, useContext ,useState} from "react";
import Header from "../components/Header";
import { Layout } from "antd";
import { Auth } from "../context/AuthContext";
import { withRouter } from "react-router";
import Datos from "../components/Datos"
import * as firebase from "firebase/app";


const Trasmitir=({history}) =>{
    const { Content, Footer } = Layout;
    const { usuario } = useContext(Auth);
    const [nombre, setnombre] = useState(null)

    useEffect(() => {
        usuario?usuario.displayName?setnombre(usuario.displayName):setnombre(usuario.email):setnombre(null)    
    }, [history, usuario]);


            return (

                <Layout style={{ height: "100vh" }}>
                    <Header
                        titulo="Chiper"
                        subtitulo=""
                    />
                    <Content style={{ padding: "0 50px", marginTop: 40 }}>
                        <div
                            style={{
                                background: "#fff",
                                padding: 24,
                                minHeight: "80vh"
                            }}
                        >
                            {nombre}
    
                            <div
                                style={{
                                    padding:100,
                                    justifyContent:"center",
                                    display:"flex"
                                
                                  
    
                                }}
                            
                            >
                                <div 
                                    style={{
                                        display:"none"
                                    }}
                                >
                                   
                                </div>
    
                                

                                

                                <div>

                                <Datos />
                                </div>
    
                              
                                
    
                        </div>
                        </div>
    
    
                    </Content>
                    <Footer style={{ textAlign: "center" }}>
                        Chiper tu aliado digital
                    </Footer>
                </Layout>
            );
        
    }

        
    
    
       
export default withRouter(Trasmitir);